#NIM/Nama       : 16019167/Carolina Sinaga
#Tanggal        : Selasa,1 Oktober 2019
#Deskripsi      : Program Perulangan yang meneriman bilangan N dan meuliskan 1 sampai N dalam satu baris

#KAMUS
#N : Jumlah banyaknya bilangan
#i : int
#N : int

#ALGORITMA
N = int(input("Masukkan N:"))
N == N
i=1                         
for i in range(1,N+1):
    print(i,end=" ")


  
    
