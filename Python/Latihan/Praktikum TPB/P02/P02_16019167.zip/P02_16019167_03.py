#NIM/NAMA   :16019167/Carolina Sinaga
#TANGGAL    :Selasa,1 Oktober 2019
#DESKRIPSI  :Program yang menggambar pola N 1-15


#KAMUS
#N: int

#ALGORIMA
N=int(input("Masukkann N:"))    
for i in range(1,N+1):              #Inisialisasi
    if (N==1):                      #Aksi
        print(1)
    elif(N>1):
        for i in range
    

    
    
