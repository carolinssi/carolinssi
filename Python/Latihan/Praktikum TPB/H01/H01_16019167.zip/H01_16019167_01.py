# NIM/NAMA  : 16019167/Carolina Sinaga
#Tanggal    : Minggu,15 September 2019
#Deskripsi  : Program yang menuliskan "Hello,World!" 



#Program Print
#ALGORITMA
print('Hello, Word!')
